
## [1.0.8] 2018-03-09
*   fix ts2policy KeyError exception
